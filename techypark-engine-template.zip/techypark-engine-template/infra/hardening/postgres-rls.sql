ALTER SYSTEM SET password_encryption = 'scram-sha-256';
CREATE ROLE appuser LOGIN NOSUPERUSER INHERIT;
REVOKE ALL ON SCHEMA public FROM PUBLIC;
ALTER DATABASE techypark OWNER TO appuser;
-- Example RLS:
-- ALTER TABLE "Site" ENABLE ROW LEVEL SECURITY;
-- CREATE POLICY site_owner ON "Site" USING (ownerId = current_setting('app.user_id')::text);
