export default function Page(){
  return (<main style={{padding:24}}>
    <h1>TechyPark Engine</h1>
    <p>Secure, fast, containerized hosting. Connect API and start provisioning.</p>
  </main>);
}
