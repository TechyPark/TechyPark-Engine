import { NextResponse } from 'next/server';
export function middleware(req: any){
  if(req.method==='POST'){
    const token = req.cookies.get('csrf')?.value;
    if(!token || token !== req.headers.get('x-csrf')) return new NextResponse('Forbidden', { status: 403 });
  }
  return NextResponse.next();
}
