import prisma from '../lib/prisma';
import { $ } from 'execa';
export async function provisionSite(siteId:string){
  const site = await prisma.site.findUniqueOrThrow({ where:{ id: siteId }});
  const cname = `site_${site.id}`;
  await $`docker network create --driver bridge techypark_net || true`;
  await $`docker run -d --pull=always --restart=always --network techypark_net --name ${cname} -e VIRTUAL_HOST=${site.name}.techypark.dev -e LETSENCRYPT_HOST=${site.name}.techypark.dev -e LETSENCRYPT_EMAIL=${process.env.SSL_EMAIL} -m 512m --cpus=0.5 -v wp_${site.id}_db:/var/lib/mysql -v wp_${site.id}_html:/var/www/html wordpress:php8.2-fpm-alpine`;
  await prisma.site.update({ where:{ id: siteId }, data:{ status:'RUNNING' }});
}
