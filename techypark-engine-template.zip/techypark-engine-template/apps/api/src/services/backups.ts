import { s3 } from '../../../packages/integrations/s3';
import { $ } from 'execa';
import { readFile } from 'fs/promises';
export async function doBackup(siteId:string){
  const path = `/tmp/${siteId}.tar.gz`;
  await $`docker run --rm -v wp_${siteId}_html:/data busybox tar -czf ${path} /data`;
  await s3.upload({ Bucket: process.env.BUCKET!, Key: `backups/${siteId}/${Date.now()}.tar.gz`, Body: await readFile(path) }).promise();
}
