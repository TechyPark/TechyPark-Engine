import Fastify from 'fastify';
import helmet from '@fastify/helmet';
import cors from '@fastify/cors';
import sensible from '@fastify/sensible';
import rateLimit from '@fastify/rate-limit';
import { siteRoutes } from './routes/sites.route';
import { authRoutes } from './routes/auth.route';
import { logger } from './lib/logger';

export const build = () => {
  const app = Fastify({ logger, trustProxy: true });
  app.register(helmet, { contentSecurityPolicy: false, crossOriginEmbedderPolicy: true });
  app.register(cors, { origin: ['http://localhost:3000'], credentials: true });
  app.register(sensible);
  app.register(rateLimit, { max: 100, timeWindow: '1 minute', ban: 3, hook: 'onSend' });

  app.register(authRoutes, { prefix: '/auth' });
  app.register(siteRoutes, { prefix: '/sites' });

  app.setErrorHandler((err, req, reply) => {
    req.log.error({ err });
    reply.code((err as any).statusCode ?? 500).send({ error: 'Internal Error' });
  });

  return app;
};
