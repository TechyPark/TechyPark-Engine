import { Worker } from 'bullmq';
import IORedis from 'ioredis';
import prisma from '../lib/prisma';
import { provisionSite } from '../services/provisioner';
import { doBackup } from '../services/backups';
const connection = new IORedis(process.env.REDIS_URL!, { maxRetriesPerRequest: null });
new Worker('provision', async job => { await provisionSite(job.data.siteId); }, { connection });
new Worker('backups',   async job => { await doBackup(job.data.siteId);   }, { connection });
