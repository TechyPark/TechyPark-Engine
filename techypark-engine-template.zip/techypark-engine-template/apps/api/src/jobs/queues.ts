import { Queue } from 'bullmq';
import IORedis from 'ioredis';
const conn = new IORedis(process.env.REDIS_URL!, { maxRetriesPerRequest: null });
export const queues = {
  provision: new Queue('provision', { connection: conn }),
  backups:   new Queue('backups',   { connection: conn }),
};
