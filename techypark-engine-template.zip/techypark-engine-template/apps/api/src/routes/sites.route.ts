import { FastifyInstance } from 'fastify';
import { z } from 'zod';
import prisma from '../lib/prisma';
import { validate } from '../middleware/validate';
import { requireAuth } from '../middleware/auth';
import { queues } from '../jobs/queues';

const createSiteDto = z.object({ name: z.string().min(3).max(63).regex(/^[a-z0-9-]+$/), plan: z.enum(['basic','pro','business']) });

export async function siteRoutes(app: FastifyInstance) {
  app.post('/', { preHandler: [requireAuth, validate(createSiteDto)] }, async (req:any) => {
    const { name, plan } = req.body;
    const site = await prisma.site.create({ data: { name, plan, ownerId: req.user.sub }});
    await queues.provision.add('provision', { siteId: site.id }, { removeOnComplete: true, attempts: 5, backoff: { type: 'exponential', delay: 5000 }});
    return { siteId: site.id, status: 'QUEUED' };
  });
  app.post('/:id/backup', { preHandler: [requireAuth] }, async (req:any) => {
    await queues.backups.add('backup', { siteId: req.params.id }, { removeOnComplete: true });
    return { ok: true };
  });
}
