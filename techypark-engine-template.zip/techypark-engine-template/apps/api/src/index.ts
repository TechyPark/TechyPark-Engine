import { build } from './app';
const app = build();
const port = Number(process.env.PORT || 8080);
app.listen({ port, host: '0.0.0.0' }).then(() => {
  app.log.info(`API listening on ${port}`);
});
