import { ZodSchema } from 'zod';
export const validate = (schema: ZodSchema) => async (req: any, reply: any) => {
  const parsed = await schema.safeParseAsync(req.body ?? {});
  if (!parsed.success) return reply.code(400).send({ error: 'INVALID_INPUT' });
  req.body = parsed.data;
};
