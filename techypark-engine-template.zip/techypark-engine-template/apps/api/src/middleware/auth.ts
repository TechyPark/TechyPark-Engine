import jwksClient from 'jwks-rsa';
import jwt from 'jsonwebtoken';
const client = jwksClient({ jwksUri: process.env.JWKS_URI! });
function getKey(header:any, cb:any){ client.getSigningKey(header.kid, (e,k)=>cb(e,(k as any)?.getPublicKey())); }
export async function requireAuth(req:any, reply:any){
  const token = (req.headers.authorization||'').replace('Bearer ','');
  if(!token) return reply.code(401).send({error:'NO_AUTH'});
  try{
    req.user = await new Promise((res, rej)=>{
      jwt.verify(token, getKey, { audience: process.env.JWT_AUD!, issuer: process.env.JWT_ISS! }, (e,d)=> e?rej(e):res(d));
    });
  }catch{ return reply.code(401).send({error:'BAD_TOKEN'}); }
}
