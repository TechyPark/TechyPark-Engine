import fetch from 'node-fetch';
export async function createDNS(name:string, ip:string){
  return fetch(`https://api.cloudflare.com/client/v4/zones/${process.env.CF_ZONE}/dns_records`, {
    method:'POST',
    headers:{ 'Authorization':`Bearer ${process.env.CF_TOKEN}`, 'Content-Type':'application/json' },
    body: JSON.stringify({ type:'A', name, content: ip, proxied:true, ttl:120 })
  });
}
