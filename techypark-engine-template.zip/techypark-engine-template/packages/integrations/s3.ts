import AWS from 'aws-sdk';
export const s3 = new AWS.S3({ endpoint: process.env.S3_ENDPOINT, s3ForcePathStyle: true, signatureVersion: 'v4' });
export const signedPut = (key:string) => s3.getSignedUrl('putObject', { Bucket: process.env.BUCKET!, Key: key, Expires: 300 });
